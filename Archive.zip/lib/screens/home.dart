import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:newsly/screens/swipe.dart';
import 'package:newsly/services/services.dart';
import 'package:provider/provider.dart';

class Home extends StatelessWidget {
  const Home({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    AuthService auth = AuthService();
    var user = Provider.of<User?>(context);
    return Scaffold(
        appBar: AppBar(
          title: const Text('Newsly'),
          automaticallyImplyLeading: false,
          actions: [
            IconButton(
              icon: const Icon(Icons.exit_to_app),
              tooltip: 'Sign Out',
              onPressed: () async {
                await auth.signOut();
                if (!context.mounted) return;
                Navigator.of(context)
                    .pushNamedAndRemoveUntil('/', (route) => false);
              },
            )
          ],
        ),
        body:  Center(
          child: Text(user!.isAnonymous ? "Hello Guest" : "Hello ${user.displayName}")
        ),
        floatingActionButton: FloatingActionButton(
          child: const Icon(Icons.rocket_launch),
          onPressed: () {
            Navigator.push(
              context,
              MaterialPageRoute(builder: (context) => const Newsly()),
            );
          },
        ));
  }
}
