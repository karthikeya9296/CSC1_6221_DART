class ArticleCandidateModel {
  String title;
  String description;
  String url;
  String urlToImage;
  String author;
  String publishedAt;
  String content;

  ArticleCandidateModel(this.author, this.title, this.description, this.url,
      this.urlToImage, this.publishedAt, this.content);
}

final List<ArticleCandidateModel> candidates = [
  ArticleCandidateModel(
      "marketwatch.com",
      "Robo-taxies remain a pipe dream and greedy companies have only themselves to blame",
      "While Tesla Inc. Chief Executive Elon Musk and others working on autonomous vehicles have suggested that robo-taxis and driverless cars are around the corner, recent developments say otherwise. In a big setback for the autonomous-vehicle industry, Cruise, the…",
      "https://biztoc.com/x/7a89b230566d8e19",
      "https://c.biztoc.com/p/7a89b230566d8e19/s.webp",
      "2023-10-28T16:14:07Z",
      "While Tesla Inc. Chief Executive Elon Musk and others working on autonomous vehicles have suggested that robo-taxis and driverless cars are around the corner, recent developments say otherwise.In a b… [+288 chars]"),
  ArticleCandidateModel(
      "247wallst.com",
      "GM’s Driverless Plans Shattered",
      "GM won’t continue its tests of driverless vehicles in the U.S. for now. Its permit to test them in California was taken away. State regulators don’t think GM “autonomous vehicles” are safe. The primary barrier to AV adoption is fear of crashes. So. far, that …",
      "https://biztoc.com/x/969fca03a403d4ae",
      "https://c.biztoc.com/p/969fca03a403d4ae/s.webp",
      "2023-10-28T16:10:07Z",
      "GM wont continue its tests of driverless vehicles in the U.S. for now. Its permit to test them in California was taken away. State regulators dont think GM autonomous vehicles are safe. The primary b… [+240 chars]"),
  ArticleCandidateModel(
      "bringatrailer",
      "19k-Mile 2018 Tesla Model S 75D at No Reserve",
      "This 2018 Tesla Model S 75D is powered by two three-phase AC induction electric motors linked with a single-speed direct drive transmission that drives all four wheels and it is finished in red over black leather upholstery. The car is equipped with a 75-kWh …",
      "https://bringatrailer.com/listing/2018-tesla-model-s-5-2/",
      "https://bringatrailer.com/wp-content/uploads/2023/10/2018_tesla_model-s_img_4978-1-33052-scaled-96uqot-1-75883.jpg",
      "2023-10-28T16:00:26Z",
      "This 2018 Tesla Model S 75D is powered by two three-phase AC induction electric motors linked with a single-speed direct drive transmission that drives all four wheels and it is finished in red over … [+2554 chars]"),
  ArticleCandidateModel(
      "Antuan Goodwin",
      "BP Buying 100M Worth of Tesla EV Chargers: What's the Big Deal? - CNET",
      "The fossil fuel conglomerate will be the first to acquire chargers directly from Tesla for its third-party network. What does that mean for EV drivers?",
      "https://www.cnet.com/roadshow/news/bp-buying-100m-worth-of-tesla-ev-chargers-whats-the-big-deal/",
      "https://www.cnet.com/a/img/resize/08f2d3439544541c25733103e419b5e8b2c312f7/hub/2023/10/27/3cc3dea1-1b2f-4c88-a308-885c35ed34ad/bp-pulse-supercharger-telsa-jpg-img-750-medium.jpg?auto=webp&fit=crop&height=675&width=1200",
      "2023-10-28T16:00:04Z",
      "Petroleum giant turned clean energy dabbler BP announced this week that it will be acquiring 100 million worth of Tesla DC fast charging hardware featuring the North American Charging Standard (NACS… [+4537 chars]"),
  ArticleCandidateModel(
      "Antuan Goodwin",
      "BP Buying 100M Worth of Tesla EV Chargers: What's the Big Deal? - CNET",
      "The fossil fuel conglomerate will be the first to acquire chargers directly from Tesla for its third-party network. What does that mean for EV drivers?",
      "https://www.cnet.com/roadshow/news/bp-buying-100m-worth-of-tesla-ev-chargers-whats-the-big-deal/",
      "https://www.cnet.com/a/img/resize/08f2d3439544541c25733103e419b5e8b2c312f7/hub/2023/10/27/3cc3dea1-1b2f-4c88-a308-885c35ed34ad/bp-pulse-supercharger-telsa-jpg-img-750-medium.jpg?auto=webp&fit=crop&height=675&width=1200",
      "2023-10-28T16:00:04Z",
      "Petroleum giant turned clean energy dabbler BP announced this week that it will be acquiring 100 million worth of Tesla DC fast charging hardware featuring the North American Charging Standard (NACS… [+4537 chars]"),
];


