class Article {
  Source? source;
  String? author;
  String? title;
  String? description;
  String? url;
  String? urlToImage;
  DateTime? publishedAt;
  String? content;

  Article({
    this.source,
    this.author,
    this.title,
    this.description,
    this.url,
    this.urlToImage,
    this.publishedAt,
    this.content,
  });

  Article.fromMap(Map data) {
    source = data[source];
    author = data[author];
    title = data[title];
    description = data[description];
    url = data[url];
    urlToImage = data[urlToImage];
    publishedAt = data[publishedAt];
    content = data[content];
  }
}

class Source {
  int? id;
  String? name;

  Source({
    this.id,
    this.name,
  });
  Source.fromMap(Map data) {
    id = data[id];
    name = data[name];
  }
}
