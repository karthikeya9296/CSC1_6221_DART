package com.example.newsly.newsly

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
